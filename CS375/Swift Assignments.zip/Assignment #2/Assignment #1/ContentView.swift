//
//  ContentView.swift
//  Assignment #1
//
//  Created by Elizabeth Dixon on 5/31/24.
//

import SwiftUI

struct ContentView: View {
    
    @State var message: String = "This frog is poisonous!"
    @State var status: Bool = false
    @State var whatPhoto: String = "dart"
    
    var body: some View {
        
        ZStack{
            
            
            Image("A1 BG")
                .resizable(resizingMode: .stretch)
                .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                .ignoresSafeArea()
                //.opacity()
                
            
            VStack {
                
                
                Text("This is a UI View.")
                    .font(.largeTitle)
                    .fontWeight(.light)
                    .multilineTextAlignment(.center)
                    .padding(0.0)
                    .dynamicTypeSize(/*@START_MENU_TOKEN@*/.accessibility2/*@END_MENU_TOKEN@*/)
                    .foregroundColor(Color(red: 0.0, green: 1.0, blue: 0.4, opacity: 1.0))
                
                
                Label(message, image: whatPhoto).foregroundColor(.red).fontWeight(.black)
                
                
                Button(action: {
                    if(status)
                    {

                        message = "This frog is poisonous!"
                        whatPhoto = "dart"
                        status = false
                    }
                    else
                    {
                        message = "This one's probably not!"
                        whatPhoto = "not"
                        status = true
                    }
                }, label: {
                    Text("Click to reveal!").foregroundColor(Color(red: 0.0, green: 1.0, blue: 0.4, opacity: 1.0)).border(/*@START_MENU_TOKEN@*/Color(hue: 0.192, saturation: 1.0, brightness: 1.0)/*@END_MENU_TOKEN@*/, width: 0.5).padding(.all).background(.black)
                })
                
                
                VStack
                {
                    
                    VStack{
                        
                        Spacer()
                        
                        HStack{
                            
                            Text("Elizabeth Dixon")
                                .fontWeight(.black)
                                .dynamicTypeSize(/*@START_MENU_TOKEN@*/.xLarge/*@END_MENU_TOKEN@*/)
                                .foregroundColor(.orange)
                            Text("is a")
                                .foregroundColor(Color(hue: 0.183, saturation: 0.053, brightness: 0.979))
                            Text("rising senior")
                                .foregroundColor(/*@START_MENU_TOKEN@*/Color(hue: 0.192, saturation: 1.0, brightness: 1.0)/*@END_MENU_TOKEN@*/)
                                .fontWeight(.black)
                                .multilineTextAlignment(.leading)
                                .dynamicTypeSize(/*@START_MENU_TOKEN@*/.xxxLarge/*@END_MENU_TOKEN@*/)
                            Image(systemName: "return")
                                .foregroundColor(.cyan)
                        }
                        
                        
                        Text("She is studying:")
                            .foregroundColor(Color(hue: 0.183, saturation: 0.053, brightness: 0.979))
                            .multilineTextAlignment(.leading)
                            .underline()
                        Text("SOFTWARE ENGINEERING")
                            .foregroundColor(.green)
                            .italic()
                            .bold()
                            .font(.title2)
                        Text("&")
                            .foregroundColor(.cyan)
                            .fontWeight(.bold)
                        Text("MUSIC INDUSTRY STUDIES")
                            .foregroundColor(.yellow)
                            .italic()
                            .bold()
                            .font(.title2)
                        
                        Text("Her hobbies include:")
                            .underline()
                            .foregroundColor(Color(hue: 0.183, saturation: 0.053, brightness: 0.979))
                        HStack
                        {
                            
                            Text("cooking")
                                .font(.headline)
                                .fontWeight(.black)
                                .foregroundColor(/*@START_MENU_TOKEN@*/Color(hue: 0.192, saturation: 1.0, brightness: 1.0)/*@END_MENU_TOKEN@*/)
                                .italic()
                            
                            Text("   ,  ")
                                .foregroundColor(Color(red: 0.0, green: 1.0, blue: 0.4, opacity: 1.0))
                            Text("listening to/playing music")
                                .foregroundColor(/*@START_MENU_TOKEN@*/Color(hue: 0.192, saturation: 1.0, brightness: 1.0)/*@END_MENU_TOKEN@*/)
                                .fontWeight(.semibold)
                            Text("   ,   ")
                                .foregroundColor(Color(red: 0.0, green: 1.0, blue: 0.4, opacity: 1.0))
                        }
                            
                        HStack{
                            Text("keeping up with media happenings")
                                .italic()
                                .foregroundColor(/*@START_MENU_TOKEN@*/Color(hue: 0.192, saturation: 1.0, brightness: 1.0)/*@END_MENU_TOKEN@*/)
                            Text("   ,   ")
                                .foregroundColor(Color(red: 0.0, green: 1.0, blue: 0.4, opacity: 1.0))
                        }
                        
                        HStack{
                            Text("&")
                                .foregroundColor(.cyan)
                            Text("trying new things out in Chattanooga!")
                                .font(.title3)
                                .foregroundColor(/*@START_MENU_TOKEN@*/Color(hue: 0.192, saturation: 1.0, brightness: 1.0)/*@END_MENU_TOKEN@*/)
                                .bold()
                        }
                        
                        
                        
                        
                        Spacer()
                        

                    }
                    
                    
                }
                
                    
                }
            }
            
        }
    }


#Preview {
    ContentView()
}
