//
//  ContentView.swift
//  Assignment #1
//
//  Created by Elizabeth Dixon on 5/31/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        
        ZStack{
            
            Image("A1 BG")
                .resizable(resizingMode: .stretch)
                .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                .ignoresSafeArea()
                .opacity(0.8)
            
            VStack {
                
                Text("This is a UI View.")
                    .font(.largeTitle)
                    .fontWeight(.light)
                    .multilineTextAlignment(.center)
                    .padding(0.0)
                    .dynamicTypeSize(/*@START_MENU_TOKEN@*/.accessibility2/*@END_MENU_TOKEN@*/)
                    .foregroundColor(Color(red: 0.0, green: 1.0, blue: 0.4, opacity: 1.0))
                    //Spacer()
                
                HStack
                {
                    Text("...Featuring a picture I took at the TN aquarium")
                        .font(.callout)
                        .fontWeight(.regular)
                        .multilineTextAlignment(.leading)
                        .lineLimit(nil)
                        .italic()
                        .underline()
                        .foregroundColor(Color(red: 0.0, green: 1.0, blue: 0.4, opacity: 1.0))
                        .dynamicTypeSize(/*@START_MENU_TOKEN@*/.medium/*@END_MENU_TOKEN@*/)
                }
                Spacer()
                
                
                VStack
                {

                    HStack{
                        Text("This is also a bit of a biography...")
                            .font(.headline)
                            .fontWeight(.medium)
                            //.padding(.trailing, 50.0)
                            .multilineTextAlignment(.leading)
                            .foregroundColor(Color(hue: 0.51, saturation: 1.0, brightness: 2.0))
                            .dynamicTypeSize(/*@START_MENU_TOKEN@*/.xxLarge/*@END_MENU_TOKEN@*/)

                    }
                    
                    
                    HStack{
                        Image(systemName: "arrow.right.to.line.alt")
                            .foregroundColor(Color(red: 0.0, green: 1.0, blue: 0.4, opacity: 1.0))
                        Image(systemName: "arrow.right.to.line.alt")
                            .foregroundColor(Color(red: 0.0, green: 1.0, blue: 0.4, opacity: 1.0))
                        Image(systemName: "arrow.right.to.line.alt")
                            .foregroundColor(Color(red: 0.0, green: 1.0, blue: 0.4, opacity: 1.0))
                        Image(systemName: "arrow.right.to.line.alt")
                            .foregroundColor(Color(red: 0.0, green: 1.0, blue: 0.4, opacity: 1.0))
                        Image(systemName: "arrow.right.to.line.alt")
                            .foregroundColor(Color(red: 0.0, green: 1.0, blue: 0.4, opacity: 1.0))
                        Image(systemName: "arrow.right.to.line.alt")
                            .foregroundColor(Color(red: 0.0, green: 1.0, blue: 0.4, opacity: 1.0))
                        Image(systemName: "arrow.right.to.line.alt")
                            .foregroundColor(Color(red: 0.0, green: 1.0, blue: 0.4, opacity: 1.0))
                        Image(systemName: "arrow.right.to.line.alt")
                            .foregroundColor(Color(red: 0.0, green: 1.0, blue: 0.4, opacity: 1.0))
                        Image(systemName: "arrow.right.to.line.alt")
                            .foregroundColor(Color(red: 0.0, green: 1.0, blue: 0.4, opacity: 1.0))
                        Image(systemName: "arrow.right.to.line.alt")
                            .foregroundColor(Color(red: 0.0, green: 1.0, blue: 0.4, opacity: 1.0))
                        Image(systemName: "arrow.right.to.line.alt")
                            .foregroundColor(Color(red: 0.0, green: 1.0, blue: 0.4, opacity: 1.0))
                        Image(systemName: "arrow.right.to.line.alt")
                            .foregroundColor(Color(red: 0.0, green: 1.0, blue: 0.4, opacity: 1.0))
                        Image(systemName: "arrow.right.to.line.alt")
                            .foregroundColor(Color(red: 0.0, green: 1.0, blue: 0.4, opacity: 1.0))
                    }
                    .padding()
                    
                    VStack{
                        HStack{
                            
                            Text("Elizabeth Dixon")
                                .fontWeight(.black)
                                .multilineTextAlignment(.leading)
                                .dynamicTypeSize(/*@START_MENU_TOKEN@*/.xLarge/*@END_MENU_TOKEN@*/)
                                .foregroundColor(Color(hue: 0.06, saturation: 0.97, brightness: 0.665))
                            Text("is a")
                                .foregroundColor(Color(hue: 0.183, saturation: 0.053, brightness: 0.979))
                            Text("rising senior")
                                .foregroundColor(/*@START_MENU_TOKEN@*/Color(hue: 0.192, saturation: 1.0, brightness: 1.0)/*@END_MENU_TOKEN@*/)
                                .fontWeight(.black)
                                .multilineTextAlignment(.leading)
                                .dynamicTypeSize(/*@START_MENU_TOKEN@*/.xxxLarge/*@END_MENU_TOKEN@*/)
                            Image(systemName: "return")
                                .foregroundColor(.cyan)
                        }
                        
                        HStack{
                            Text("@")
                                .fontWeight(.black)
                                .foregroundColor(.cyan)
                            Text("BUTLER UNIVERSITY.")
                                .foregroundColor(Color(hue: 0.637, saturation: 0.982, brightness: 0.434))
                                .fontWeight(.bold)
                                .dynamicTypeSize(/*@START_MENU_TOKEN@*/.xxLarge/*@END_MENU_TOKEN@*/)
                            Image(systemName: "return")
                                .foregroundColor(.cyan)
                            
                        }
                        
                        .padding()
                        Spacer()
                        
                        Text("She is studying:")
                            .foregroundColor(Color(hue: 0.183, saturation: 0.053, brightness: 0.979))
                            .multilineTextAlignment(.leading)
                            .underline()
                        Text("")
                        Text("SOFTWARE ENGINEERING")
                            .foregroundColor(.green)
                            .italic()
                            .bold()
                            .font(.title2)
                        Text("&")
                            .foregroundColor(.cyan)
                            .fontWeight(.bold)
                        Text("MUSIC INDUSTRY STUDIES")
                            .foregroundColor(.yellow)
                            .italic()
                            .bold()
                            .font(.title2)

                        Spacer()
                        Text("Her hobbies include:")
                            .underline()
                            .foregroundColor(Color(hue: 0.183, saturation: 0.053, brightness: 0.979))
                        Text("")
                        HStack
                        {
                            
                            Text("cooking")
                                .font(.headline)
                                .fontWeight(.black)
                                .foregroundColor(.red)
                                .italic()
                            
                            Text("   ,  ")
                                .foregroundColor(.cyan)
                            Text("listening to/playing music")
                                .foregroundColor(.orange)
                                .fontWeight(.semibold)
                            Text("   ,   ")
                                .foregroundColor(.cyan)
                            Image(systemName: "return")
                                .foregroundColor(.cyan)
                        }
                            
                        HStack{
                            Text("keeping up with media happenings")
                                .italic()
                                .foregroundColor(.yellow)
                            Text("   ,   ")
                                .foregroundColor(.cyan)
                            Image(systemName: "return")
                                .foregroundColor(.cyan)
                        }
                        
                        HStack{
                            Text("&")
                                .foregroundColor(.cyan)
                            Text("trying new things out in Chattanooga!")
                                .font(.title3)
                                .foregroundColor(.mint)
                                .bold()
                        }
                        
                        Spacer()
                    }
                    
                }
                    
                .padding()
                .padding()
                
                    
                    
                    //Spacer(minLength: 550)
                }
            .padding()
            .padding()

            
                //Spacer(minLength: 725)
            }
            
        }
    }


#Preview {
    ContentView()
}
