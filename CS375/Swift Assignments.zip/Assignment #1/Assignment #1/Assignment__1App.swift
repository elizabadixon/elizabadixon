//
//  Assignment__1App.swift
//  Assignment #1
//
//  Created by Elizabeth Dixon on 5/31/24.
//

import SwiftUI

@main
struct Assignment__1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
