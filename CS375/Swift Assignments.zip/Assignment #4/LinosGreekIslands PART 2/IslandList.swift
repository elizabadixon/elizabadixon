//
//  IslandList.swift
//  LinosGreekIslands PART 2
//
//  Created by Elizabeth Dixon on 6/22/24.
//

import SwiftUI

struct IslandList: View {
    
    @State private var showFavoritesOnly = false
    
    var filteredIslands: [Island] {
        islands.filter { island in
            (!showFavoritesOnly || island.isFavorite)
        }
    }
    
    var body: some View {
        NavigationSplitView {
            List {
                Toggle (isOn: $showFavoritesOnly) {
                    Text("Favorited Islands Only")
                }
                ForEach(filteredIslands) { island in
                    NavigationLink {
                        IslandDetailsView(island: island)
                    } label: {
                        IslandRow(island: island)
                    }
                }
            }
            .animation(.default, value: filteredIslands)
            .navigationTitle("Favorite Islands")
        } detail: {
            Text("Select an Island")
        }
    }
}

#Preview {
    IslandList()
}
