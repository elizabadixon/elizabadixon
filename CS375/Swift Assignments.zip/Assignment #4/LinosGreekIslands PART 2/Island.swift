//
//  Island.swift
//  LinosGreekIslands PART 2
//
//  Created by Elizabeth Dixon on 6/22/24.
//

import SwiftUI

//a struct to store exactly one island's data
struct Island: Identifiable, Hashable, Codable{
    
    var id: UUID = UUID()
    let name: String
    let description: String
    let attractions: String
    let photo: String
    var isFavorite: Bool
}


//#Preview {
//    Island()
//}
