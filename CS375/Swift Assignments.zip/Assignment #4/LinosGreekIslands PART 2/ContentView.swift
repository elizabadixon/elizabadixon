//
//  ContentView.swift
//  LinosGreekIslands PART 2
//
//  Created by Linos, Panos on 5/26/21.
//

import SwiftUI



//create a few islands and then show them in a List
struct ContentView: View {

    @State private var isPresented: Bool = false
    @State private var nameText: String = ""
    @State private var descriptionText: String = ""
    @State private var attractionsText: String = ""
    @State private var editMode = EditMode.inactive
    
    @State private var islands: [Island] = [
        Island (name: "Santorini", description: "Aegean sea", attractions: "Best sunset view! Excellent place to get married.", photo: "Santorini"),
        Island (name: "Mykonos", description: "Aegean sea", attractions: "Cosmopolitan life style. Best night life ever.", photo: "Mykonos"),
        Island (name: "Skiathos", description: "Aegean sea", attractions: "Amazing local cuisine.", photo: "Skiathos"),
        Island (name: "Crete", description: "Mediterranean sea.", attractions: "Biggest island. You can find ocean to mountain views.", photo: "Crete"),
        Island (name: "Corfu", description: "Ionian see", attractions: "Beautifull green landscapes.", photo: "Corfu"),
        Island (name: "Zakynthos", description: "Aegean sea", attractions: "Many water sports and activities.", photo: "Zakynthos"),
        Island (name: "Paros", description: "Aegean sea", attractions: "Amazing white rock water front.", photo: "Paros")
    ]
    
    var body: some View {
        
        //IslandList()
        
        NavigationView {
            
            ZStack { //used for the overlapping alert box
                List {
                    ForEach (islands, id: \.self) { island in
                        NavigationLink(destination: IslandDetailsView(island: island)) {
                            HStack {
                                IslandRow(island: island)
                                VStack(alignment: .leading) {
                                    Text(island.name)
                                        .font(.headline)
                                    Text(island.description)
                                        .foregroundColor( .blue)
                                }
                                .padding(7)
                            }
                        }
                    }
                    .onDelete(perform: deleteIsland)
                    .onMove(perform: onMove)
                }
                .navigationBarTitle("Greek Islands")
                .navigationBarItems(leading: EditButton(), trailing: addButton)
                .environment(\.editMode, $editMode)
                
                showAlertBox
            }
            
        }
    }
    
    private func deleteIsland(offsets: IndexSet) {
        islands.remove(atOffsets: offsets)
    }
    
    private var addButton: some View {
        switch editMode {
        case .inactive:
            return AnyView(Button(action: {self.isPresented = true})
                { Image(systemName: "plus")})
        default:
            return AnyView(EmptyView())
        }
    }
    
    //show an alert with textfields to get user input
    private var showAlertBox: some View {
        
        return  AlertTextFieldView(title: "Add New Island", isShown: $isPresented, nameText: $nameText, descriptionText: $descriptionText, attractionsText: $attractionsText, onDone: { _,_,_  in addNewIsland()})
        
    }
    
    private func addNewIsland() {
        
        //a default island photo is added to the list
        let newIsland = Island(name: nameText, description: descriptionText, attractions: attractionsText, photo: "NewIsland")
        
        //self.islands.append(newIsland)
        self.islands.insert(newIsland, at: 0)
        
    }
    
    private func onMove(source: IndexSet, destination: Int) {
        islands.move(fromOffsets: source, toOffset: destination)
    }
    
    struct ContentView_Previews: PreviewProvider {
        static var previews: some View {
            ContentView()
        }
    }
}

#Preview {
    ContentView()
}
