//
//  LinosGreekIslands_PART_2App.swift
//  LinosGreekIslands PART 2
//
//  Created by Linos, Panos on 5/26/21.
//

import SwiftUI

@main
struct LinosGreekIslands_PART_2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
