//
//  AlertTextFieldView.swift
//  LinosGreekIslands PART 2
//
//  Created by Linos, Panos on 5/26/21.
//

import SwiftUI

struct AlertTextFieldView: View {
    
    let screenSize = UIScreen.main.bounds
    
    var title: String = ""
    @Binding var isShown: Bool
    @Binding var nameText: String
    @Binding var descriptionText: String
    @Binding var attractionsText: String
    var onDone: (String, String, String) -> Void = { _,_,_  in }
    var onCancel: () -> Void = { }
    
    var body: some View {
        VStack {
            
            Text(title)
            
            TextField("Enter island name...", text: $nameText)
                .textFieldStyle(RoundedBorderTextFieldStyle())
            TextField("Enter brief description...", text: $descriptionText)
                .textFieldStyle(RoundedBorderTextFieldStyle())
            TextField("Enter brief attractions...", text: $attractionsText)
                .textFieldStyle(RoundedBorderTextFieldStyle())
            
            HStack{
                Spacer()
                Button("Done") {
                    self.isShown = false
                    self.onDone(self.nameText,
                                self.descriptionText,
                                self.attractionsText)
                }
                Spacer()
                Button("Cancel") {
                    self.isShown = false
                    self.onCancel()
                }
                Spacer()
            }
            
        }//formatting the alert box
        .padding()
        .frame(width: screenSize.width * 0.7, height: screenSize.height * 0.5)
        .background(Color(UIColor.lightGray))
        .clipShape(RoundedRectangle(cornerRadius: 20.0,style: .continuous ))
        .offset(y: isShown ? 0 : screenSize.height)
        withAnimation(.spring())
        .shadow(color: Color(UIColor.lightGray), radius: 6, x: -9, y: -9)
    }
}

struct AlertTextFiledView_Previews: PreviewProvider {
    static var previews: some View {
        AlertTextFieldView(isShown: .constant(true), nameText: .constant(""), descriptionText: .constant(""), attractionsText: .constant(""))
    }
}
