//
//  IslandDetailsView.swift
//  LinosGreekIslands PART 2
//
//  Created by Elizabeth Dixon on 6/22/24.
//

import SwiftUI

//A view that shows more details about a selected island
struct IslandDetailsView: View {
    
    var island: Island
    
    var body: some View {
        VStack(alignment: .leading) {
            HStack {
                IslandRow(island: island)
                    .padding(.trailing, 5)
                Text(island.name)
                    .font(.largeTitle)
                    .bold()
                Spacer()
            }
            Text(island.attractions)
                .padding(.top)
            Spacer()
        }
        .padding()
        .navigationBarTitle(Text(island.name), displayMode: .inline)
    }
}

//#Preview {
//    IslandDetailsView()
//}
