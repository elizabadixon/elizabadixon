//
//  IslandRow.swift
//  LinosGreekIslands PART 2
//
//  Created by Elizabeth Dixon on 6/22/24.
//

import SwiftUI

//a View that shows the data of one island
struct IslandRow: View {
    
    var island: Island
    
    var body: some View {
        HStack {
            Image(island.photo)
                .resizable()
                .frame(width: 50, height: 50)
            
            if island.isFavorite {
                Image(systemName: "heart.fill")
                    .foregroundColor(.orange)
            }
            
        }
    }
}

#Preview {
    IslandRow(island: islands[0])
}
