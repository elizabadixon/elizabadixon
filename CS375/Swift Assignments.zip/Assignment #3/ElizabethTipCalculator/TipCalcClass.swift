//
//  TipCalcClass.swift
//  ElizabethTipCalculator
//
//  Created by Elizabeth Dixon on 6/10/24.
//

import Foundation

class tipCalculator
{
    //properties
    var total: Double
    var taxPct: Double
    
    var subtotal: Double {
        return total / (taxPct + 1) //plain total - tax
    }
    
    init(total: Double, taxPct: Double) {
        self.total = total
        self.taxPct = taxPct
    }
    
    func calculateTip(tipPct: Double) -> Double {
        return round(subtotal * tipPct)
    }

    func calculateSuggTip(suggestedTips: [Double]) -> [Int: Double] {
        
        //makes [tipPct : actual tip amount]
        var tipDict = [Int: Double]()
        
        for per in suggestedTips {
            let intPct = Int(per * 100) //makes the suggested -> int
            tipDict[intPct] = calculateTip(tipPct: per)
        }
        
        return tipDict
    }
    
    
}
