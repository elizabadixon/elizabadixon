//
//  ElizabethTipCalculatorApp.swift
//  ElizabethTipCalculator
//
//  Created by Elizabeth Dixon on 6/6/24.
//

import SwiftUI

@main
struct ElizabethTipCalculatorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
