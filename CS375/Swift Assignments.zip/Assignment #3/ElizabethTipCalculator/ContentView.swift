//
//  ContentView.swift
//  ElizabethTipCalculator
//
//  Created by Elizabeth Dixon on 6/6/24.
//

import SwiftUI

struct ContentView: View {
    //declarations
    
    //main variables
    @State private var billTotal: String = ""
    @State private var salesTax: Double = 0.0
    @State private var tipInclResult: String = "0.0"
    @State private var beforeTax: Double = 0.0
    @State private var grandTotal: Double = 0.0
    @State private var isEditingSlider = false
    @State private var isTip1 = false
    @State private var isTip2 = false
    @State private var isTip3 = false
    
    
    //tip calculator object
    var tipCalcObj = tipCalculator(total: 0.0, taxPct: 0.0)
    
    //suggested tip percentages
    //let suggestedTips = [0.15, 0.18, 0.20]
    let suggestedTip1 = [0.15]
    let suggestedTip2 = [0.18]
    let suggestedTip3 = [0.20]
    
    
    var body: some View {
        
        ZStack{
            
            Color.purple
                .cornerRadius(150.0)
                .ignoresSafeArea()
                
            VStack{
                
                Spacer()
                
                Text("Welcome to the Dixon Café's Tip Calculator!")
                    .font(.title)
                    .foregroundColor(Color(hue: 0.519, saturation: 0.249, brightness: 1.0))
                    .multilineTextAlignment(.center)
                    .padding([.top, .leading, .trailing])

                Spacer()
                
                HStack{
                    Text("Please enter your bill's total (w/ Tax):")
                        .padding(.all)
                        .foregroundColor(/*@START_MENU_TOKEN@*/Color(hue: 1.0, saturation: 1.0, brightness: 0.276)/*@END_MENU_TOKEN@*/)
                }
                
                TextField("Enter Amount Here", text: $billTotal)
                    .frame(width: 200.0, height: 50.0)
                    .border(Color.black, width: 1)
                    .background()
                    .scaledToFit()
                    .multilineTextAlignment(.center)
                    .padding(.bottom)
                    .foregroundColor(/*@START_MENU_TOKEN@*/Color(hue: 1.0, saturation: 1.0, brightness: 0.276)/*@END_MENU_TOKEN@*/)
                
                
                HStack{
                    Toggle("15%", isOn: $isTip1).toggleStyle(SwitchToggleStyle(tint: Color.yellow)).padding(.all)
                    Toggle("18%", isOn: $isTip2).toggleStyle(SwitchToggleStyle(tint: Color.orange)).padding(.all)
                    Toggle("20%", isOn: $isTip3).toggleStyle(SwitchToggleStyle(tint: Color.red)).padding(.all)
                    
                }
                
                //Spacer()
                
                Text("Set your location's sales tax using the slider below:")
                    .padding(.all)
                    .multilineTextAlignment(.center)
                    .foregroundColor(/*@START_MENU_TOKEN@*/Color(hue: 1.0, saturation: 1.0, brightness: 0.276)/*@END_MENU_TOKEN@*/)
                HStack{
                    Slider(value: $salesTax,
                           in: 0...25,
                           onEditingChanged: {editing in
                        isEditingSlider = editing})
                    .padding([.leading, .bottom, .trailing])
                    
                    Text("\(round(salesTax))" + "%")
                        .padding([.bottom, .trailing])
                        .foregroundColor(/*@START_MENU_TOKEN@*/Color(hue: 1.0, saturation: 1.0, brightness: 0.276)/*@END_MENU_TOKEN@*/)
                }
                
                
                
                
                Button("Calculate Tip Options", action: {
                    tipCalcObj.taxPct = salesTax / 100
                    //let BILLTOTAL = billTotal
                    
                    
                    if let totalBillAmount = Double(billTotal)
                    {
                        //don't allow negatives
                        if(totalBillAmount >= 0)
                        {
                            tipCalcObj.total = totalBillAmount
                            beforeTax = tipCalcObj.total - salesTax
                           
                            
                            if isTip1 {
                                
                                let tipPossibilities = tipCalcObj.calculateSuggTip(suggestedTips: suggestedTip1)
                                
                                //store traversal using result
                                var result = ""
                                for(tipPct, tipValue) in tipPossibilities{
                                    result += "A \(tipPct)% tip = $\(tipValue) \n"
                                    grandTotal = tipValue + tipCalcObj.total
                                }
                                
                                tipInclResult = "Here is your bill summary: \n\n" + result + "Total before tax: $\(beforeTax)\n Tax: $\(salesTax) \n Your total (w/ tax) is: $\(billTotal)\n The total (w/ tip): $\(grandTotal)"
                                
                            }
                            
                            if isTip2 {
                                
                                let tipPossibilities = tipCalcObj.calculateSuggTip(suggestedTips: suggestedTip2)
                                
                                //store traversal using result
                                var result = ""
                                for(tipPct, tipValue) in tipPossibilities{
                                    result += "A \(tipPct)% tip = $\(tipValue) \n"
                                    grandTotal = tipValue + tipCalcObj.total
                                }
                                
                                tipInclResult = "Here is your bill summary: \n\n" + result + "Total before tax: $\(beforeTax)\n Tax: $\(salesTax) \n Your total (w/ tax) is: $\(billTotal)\n The total (w/ tip): $\(grandTotal)"
                                
                            }
                            
                            if isTip3 {
                                
                                let tipPossibilities = tipCalcObj.calculateSuggTip(suggestedTips: suggestedTip3)
                                
                                //store traversal using result
                                var result = ""
                                for(tipPct, tipValue) in tipPossibilities{
                                    result += "A \(tipPct)% tip = $\(tipValue) \n"
                                    grandTotal = tipValue + tipCalcObj.total
                                }
                                
                                tipInclResult = "Here is your bill summary: \n\n" + result + "Total before tax: $\(beforeTax)\n Tax: $\(salesTax) \n Your total (w/ tax) is: $\(billTotal)\n The Total (w/ tip): $\(grandTotal)"
                                
                            }
                            
                            
                        } else {
                            tipInclResult = "Please enter a value greater than 0 for your bill total."
                            
                        }
                    }else {
                        tipInclResult = "Please enter a numeric value greater than 0 for your bill total."
                        
                    }
                    
                })
                .frame(width: 200.0, height: 50.0)
                .border(Color.white, width: 1)
                .background(Color.blue)
                .scaledToFit()
                .multilineTextAlignment(.center)
                .foregroundColor(.white)
                .bold()
                .padding(.bottom)
                
                
                Text(tipInclResult)
                    .foregroundColor(/*@START_MENU_TOKEN@*/Color(hue: 1.0, saturation: 1.0, brightness: 0.276)/*@END_MENU_TOKEN@*/)
                    .multilineTextAlignment(.center)
                    //.padding(.bottom)
                
                //Spacer()
                
                Button("Clear All", action: {
                    billTotal = ""
                    tipInclResult = ""
                    salesTax = 0.0
                    isTip1 = false
                    isTip2 = false
                    isTip3 = false
                })
                .frame(width: 100.0, height: 50.0)
                .border(Color.white, width: 1)
                .background(Color.blue)
                .scaledToFit()
                .multilineTextAlignment(.center)
                .foregroundColor(.white)
                .bold()
                .padding(.all)
                
                
            }
            
        }
    }
        
}


#Preview {
    ContentView()
}
